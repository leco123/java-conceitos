package br.com.projeto.estudo.conhecimentosb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConhecimentoSbApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConhecimentoSbApplication.class, args);
	}

}
