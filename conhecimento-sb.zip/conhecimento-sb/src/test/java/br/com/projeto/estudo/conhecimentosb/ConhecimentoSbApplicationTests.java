package br.com.projeto.estudo.conhecimentosb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConhecimentoSbApplicationTests {

	@Test
	void contextLoads() {
	}

}
